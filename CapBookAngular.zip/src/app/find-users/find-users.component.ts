import { Component, OnInit, Input } from '@angular/core';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-find-users',
  templateUrl: './find-users.component.html',
  styleUrls: ['./find-users.component.css']
})
export class FindUsersComponent implements OnInit {

  /* @Input() */
  profilesList:Profile[];

  constructor() { }

  ngOnInit() {
    this.profilesList=JSON.parse(localStorage.getItem("profilesList"))
    console.log("hello")
    console.log(this.profilesList)
  }

}
