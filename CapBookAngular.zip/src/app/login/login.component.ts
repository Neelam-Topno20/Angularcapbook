import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  error:string;
  message:string;
  profile:Profile;
  _emailId:string='';
  _password:string='';

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) {}

  get emailId(): string{
    return this._emailId;
  }

  set emailId(value: string){
    this._emailId = value;
  }

  get password(): string{
    return this._password;
  }

  set password(value: string){
    this._password = value;
  }

  ngOnInit() {
  }

  onLoginClick(){
    const userCredentials:any={
      emailId:this.emailId,
      password:this.password
    }
    this.capbookService.loginUser(userCredentials).subscribe(
      profile=>{
        console.log(JSON.stringify(profile));
        this.profile=profile;
        localStorage.setItem("currentProfile",JSON.stringify(profile));
        localStorage.setItem("isLoggedIn","true");
        this.message='Login Successfull!!';
        this.router.navigate(['\myProfile']);
      },
      error=>{
        this.error=error;
      }
    );
    
  }

}
