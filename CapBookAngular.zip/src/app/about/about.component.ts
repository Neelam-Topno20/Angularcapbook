import { Component, OnInit } from '@angular/core';
import { Profile } from '../registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  currentProfile:Profile;
  
  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) {
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
   }

  ngOnInit() {
  }

}
