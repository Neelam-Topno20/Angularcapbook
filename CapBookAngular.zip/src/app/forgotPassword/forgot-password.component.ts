import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CapbookService } from '../services/capbook.service';
import { Profile } from '../registration/profile';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  error:string;
  message:string='';
  _emailId:string='';
  _securityQuestion:string='';
  _securityAnswer:string='';
  
  profile:Profile;
  currentProfile:Profile;
  

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { 

  }
  get emailId(): string{
    return this._emailId;
  }

  set emailId(value: string){
    this._emailId = value;
  }

  get securityQuestion(): string{
    return this._securityQuestion;
  }

  set securityQuestion(value: string){
    this._securityQuestion = value;
  }

  get securityAnswer(): string{
    return this._securityAnswer;
  }

  set securityAnswer(value: string){
    this._securityAnswer = value;
  }

  ngOnInit() {
  }

  onClickRetrievePassword(){
    const profile:any={
      emailId:this.emailId,
      securityQuestion:this.securityQuestion,
      securityAnswer:this.securityAnswer

    }

    this.capbookService.forgotPassword(profile).subscribe(
      profile=>{
        console.log(JSON.stringify(profile));
        this.profile=profile;
        localStorage.setItem("currentProfile",JSON.stringify(profile));
        this.message='Password changed successfully';
      },
      error=>{
        this.error=error;
      }
    );

}

onHomePageClick(){
  this.router.navigate(['/frontPage']);
}
}
