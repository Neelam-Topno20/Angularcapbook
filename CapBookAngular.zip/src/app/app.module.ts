import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';

import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewProfileComponent } from './viewProfile/view-profile.component';
import { FrontPageComponent } from './frontPage/front-page.component';
import { FriendComponent } from './friend/friend.component';
import { PageComponent } from './page/page.component';
import { PostComponent } from './post/post.component';
import { MyProfileComponent } from './myProfile/my-profile.component';
import { ProfilePhotoComponent } from './profilePhoto/profile-photo.component';
import { EditProfileComponent } from './editProfile/edit-profile.component';
import { AccountSettingsComponent } from './accountSettings/account-settings.component';
import { ChangePasswordComponent } from './changePassword/change-password.component';
import { ForgotPasswordComponent } from './forgotPassword/forgot-password.component';
import { FriendsListComponent } from './friend/friendsList/friends-list.component';
import { AuthorizeService } from './AuthorizeService/authorize.service';
import { AddPostComponent } from './post/addPost/add-post.component';
import { AboutComponent } from './about/about.component';
import { PhotosComponent } from './photos/photos.component';
import { FindUsersComponent } from './find-users/find-users.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    RegistrationComponent,
    ViewProfileComponent,
    FrontPageComponent,
    FriendComponent,
    PageComponent,
    PostComponent,
    MyProfileComponent,
    ProfilePhotoComponent,
    EditProfileComponent,
    AccountSettingsComponent,
    ChangePasswordComponent,
    ForgotPasswordComponent,
    FriendsListComponent,
    AddPostComponent,
    AboutComponent,
    PhotosComponent,
    FindUsersComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'frontPage',component:FrontPageComponent},
      {path: 'forgotPassword',component:ForgotPasswordComponent,},
      {path: '',redirectTo:'frontPage',pathMatch: 'full'},
      {path: 'myProfile',component:MyProfileComponent,
        children:[
          {path: 'editProfile',component:EditProfileComponent,canActivate:[AuthorizeService]},
          {path: 'posts',component:PostComponent,canActivate:[AuthorizeService]},
          {path: 'friendsList',component:FriendsListComponent,canActivate:[AuthorizeService]},
          {path: 'photos',component:PhotosComponent,canActivate:[AuthorizeService]},
          {path: 'likedPages',component:FriendComponent,canActivate:[AuthorizeService]},
          {path: 'about',component:AboutComponent,canActivate:[AuthorizeService]},
          {path: 'find-users',component:FindUsersComponent,canActivate:[AuthorizeService]},
          {path: 'accountSettings', component:AccountSettingsComponent,
          children:[
            {path: 'changePassword',component:ChangePasswordComponent,canActivate:[AuthorizeService]}
        ],canActivate:[AuthorizeService]}
        ]
        ,canActivate:[AuthorizeService]}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
