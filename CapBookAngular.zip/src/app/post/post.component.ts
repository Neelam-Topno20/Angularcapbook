import { Component, OnInit } from '@angular/core';
import { AddPostComponent } from './addPost/add-post.component';
import { Post } from './post';
import { CapbookService } from '../services/capbook.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  postList:Post[]
  constructor(private capbookService:CapbookService) { }

  ngOnInit() {
    this.capbookService.getPost().subscribe(
      postList=>{
        this.postList=postList.reverse()
        console.log(this.postList)
        console.log("get post list")
              },
      error=>{
        console.log("error")
      }
    );

  }

}
