export interface Post {
}
