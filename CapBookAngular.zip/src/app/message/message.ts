export interface Message {
	 senderEmailId:string;
	 receiverEmailId:string;
	 message:string;
}
