import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recieved-messages',
  templateUrl: './recieved-messages.component.html',
  styleUrls: ['./recieved-messages.component.css']
})
export class RecievedMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
