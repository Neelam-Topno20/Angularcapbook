import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { Profile } from 'src/app/registration/profile'

@Component({
  selector: 'app-friends-list',
  templateUrl: './friends-list.component.html',
  styleUrls: ['./friends-list.component.css']
})

export class FriendsListComponent implements OnInit {


  friendList:Profile[]
  profile:Profile

  constructor(private capBookService:CapbookService) { }

  ngOnInit() {
    this.profile=JSON.parse(localStorage.getItem("currentProfile"))

    this.capBookService.getFriendList(this.profile).subscribe(
      friendList=>{
        this.friendList=friendList;
        console.log(friendList)
        console.log("in friendlist")
      },
      error=>{
        console.log("error")
      }
    );
  }
  


}
