import { Component, OnInit } from '@angular/core';
import { Profile } from '../registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  currentProfile:Profile;

  fileToUpload:File=null;

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { 
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
  }

  handleFileInput(files:FileList){
    this.fileToUpload=files.item(0);
    this.uploadFileToActivity();
  }

  uploadFileToActivity(){
    console.log("in upload");
    this.capbookService.setProfilePic(this.fileToUpload).subscribe(
      data =>{
        console.log("success")
      },
      error => {
        console.log(error);
    });
  }


  ngOnInit() {

  }

  get listFilter(): string{
    return this._listFilter;
  }

  _listFilter:string;

  set listFilter(value: string){
    this._listFilter = value;
    this.doProductFiltering(this._listFilter);
    //this.profilesList=this._listFilter ? this.doProductFiltering(this.listFilter):this.profiles;
  }

  profilesList:Profile[];

  doProductFiltering(userName:string) {
     this.capbookService.searchUser(userName).subscribe(
      profilesList=>{
        this.profilesList=profilesList
        console.log("success")
        console.log(this.profilesList)
        localStorage.setItem("profilesList",JSON.stringify(this.profilesList));
       console.log("hey")
      console.log(JSON.parse(localStorage.getItem("profilesList")))
      },
      error =>{
        console.log("error")
      }
      
    );
    
    //filterBy = filterBy.toLowerCase();
    //return this.profiles.filter(profile => profile.firstName.toLowerCase().indexOf(filterBy)!==-1 );
  }

  profiles:Profile[];
  
  onLogOutClick(){
    localStorage.clear();
    localStorage.setItem("isLoggedIn","false");
    this.router.navigate(['/frontPage']);
  }

}
