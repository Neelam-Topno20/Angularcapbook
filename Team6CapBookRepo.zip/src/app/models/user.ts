export class User {
    emailId: string;
    password: string;
}