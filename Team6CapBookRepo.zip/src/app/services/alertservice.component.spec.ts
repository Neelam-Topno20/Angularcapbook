import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertserviceComponent } from './alertservice.component';

describe('AlertserviceComponent', () => {
  let component: AlertserviceComponent;
  let fixture: ComponentFixture<AlertserviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlertserviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
