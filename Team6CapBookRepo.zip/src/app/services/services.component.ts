import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { User } from '../models';
import { Observable, of, throwError } from 'rxjs';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})

@Injectable()
export class ServicesComponent  {
    private _URL: string;
  constructor(private http: HttpClient) {
    this._URL = 'http://localhost/8085/';
   }

    getAll() {
        return this.http.get<User[]>(`/users`);
    }

    getById(id: number) {
        return this.http.get(`/users/` + id);
    }
    getResponse(pParams){
        return this.http.get(this._URL, {params: pParams, observe: 'response'});
      }
      
    public register(productForm:FormGroup):Observable<HttpEvent<any>> {
        let body = JSON.parse(JSON.stringify(productForm.value));
        this.http.post<string>("http://localhost:8085/registerUser",body).subscribe();
      
        return of(new HttpResponse({ status: 200 }));   
     }
    
    update(user: User) {
        return this.http.put(`/users/` + user, user);
    }

    delete(id: number) {
        return this.http.delete(`/users/` + id);
    }

}
