import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse, HttpParams,HttpResponse } from '@angular/common/http';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { from, Observable, throwError } from 'rxjs';
import { ServicesComponent} from './services.component'


@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css']
})

@Injectable()
export class AuthenticationComponent{
    private _URL: string;
    _error:string;
    
    constructor(private http: HttpClient,serviceComponent:ServicesComponent) {
        this._URL = 'http://localhost/8085/';
       }

  login(emailId: string, password: string):Observable<string>{

            return this.http.post<any>(`http://localhost:8085/loginUser`, { emailId: emailId, password: password })
            .pipe(
                /*catchError(
                err => {
                    if (err.status === 400) {
                        // auto logout if 400 response returned from api
                        this.logout();
                        location.reload(true);
                    }
                    const error = err.error.message || err.statusText;
                    return throwError(error);
                })*/
                );


        }
     
        
  logout() {
      // remove user from local storage to log user out
      localStorage.removeItem('currentUser');
  }
}

