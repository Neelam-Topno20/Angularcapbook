export interface Profile {
    emailId:string;
    password:string;
    firstName:string;
    lastName:string;
    dateOfBirth:string;
    gender:string;
    homeTown:string;
    dateOfJoining:string;
    userBio:string;
    currentCity:string;
    designation:string;
    highestEducation:string;
    relationshipStatus:string;
}
