import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule, MatToolbarModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { RouterModule } from '@angular/router';
import { CapBookService } from './services/cap-book.service';
import { UserLoginComponent } from './user-login/user-login.component';
import { HttpClientModule } from '@angular/common/http';
import { ProfilePageComponent } from './profile-page/profile-page.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { SearchFriendsComponent } from './search-friends/search-friends.component';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    UserLoginComponent,
    ProfilePageComponent,
    EditProfileComponent,
    SearchFriendsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'edit-profile', component:EditProfileComponent},
      { path: '',redirectTo:'user-registration',pathMatch:'full'},
      { path: 'user-registration',component:UserRegistrationComponent},
      { path: 'user-profile',component:ProfilePageComponent},
      { path: 'search-friends',component:SearchFriendsComponent},
    ]),
  ],
  exports: [MatButtonModule, MatToolbarModule],
  providers: [CapBookService],
  bootstrap: [AppComponent],
  
})
export class AppModule { }
