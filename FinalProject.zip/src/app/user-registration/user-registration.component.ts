import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {

/*   errorMessage:string;
  message:string;
  constructor(private capbookService:CapBookService) { }

  registrationForm = new FormGroup({
    emailId: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
    firstName:new FormControl(''),
    lastName:new FormControl(''),
    dateOfBirth:new FormControl(''),
    gender:new FormControl(''),
    relationshipStatus:new FormControl(''),
    workPlace:new FormControl(''),
  })


  onSubmit():void{
    console.log("In OnSubmit")
    if((this.registrationForm.get('password').value)!=(this.registrationForm.get('confirmPassword').value)){
      console.log("In If")
      this.errorMessage="Password Does Not Match";
    }
    else{
      console.log("In Else")
    this.capbookService.userRegistration(this.registrationForm).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
    }
  } */
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private capbookService:CapBookService) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          emailId: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]],
          confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
          dateOfBirth:['',Validators.required],
          gender:['',Validators.required],
         workPlace:['',Validators.required]
      });
  }

  errorMessage:string;
  message:string;
  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
      this.submitted = true;

      if((this.registerForm.get('password').value)!=(this.registerForm.get('confirmPassword').value)){
        console.log("In If")
        this.errorMessage="Password Does Not Match";
      }
      else{
        console.log("In Else")
      this.capbookService.userRegistration(this.registerForm).subscribe(
        message=>{
          this.message=message;
        },
        errorMessage=>{
          this.errorMessage=errorMessage;
        }
      )
      }
      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!!')
  }

}
