import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from '../profile';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  errorMessage:string;
  message:Profile;
  loginForm: FormGroup;
  errorMessage2:string;
  constructor(private formBuilder: FormBuilder,private capbookService:CapBookService, private route: ActivatedRoute,private router:Router) { }

  onSubmit():void{
    localStorage.setItem("currentUser",JSON.stringify(this.loginForm.value));
    this.capbookService.userLogin(this.loginForm).subscribe(
      message=>{
        this.message=message;
        console.log("In OnSubmit") 
      },
      errorMessage=>{
        this.errorMessage="Invalid Emalid or password";
        this.router.navigateByUrl('/user-profile'); 
       
        console.log("Error Message!!!")

        
      }

      )
     // this.router.navigate(['user-profile'])
      //this.router.navigateByUrl('/user-profile');  
     // alert(this.errorMessage);
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    })
  }

}
