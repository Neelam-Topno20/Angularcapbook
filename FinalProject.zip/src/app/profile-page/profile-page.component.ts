import { Component, OnInit } from '@angular/core';
import { Profile } from 'selenium-webdriver/firefox';
import { CapBookService } from '../services/cap-book.service';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  fileToUpload: File = null;
  currentUser:Profile;
  constructor(private capBookService:CapBookService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }
  
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadFileToActivity();
}

 uploadFileToActivity() {
  console.log("in upload");
  this.capBookService.postFile(this.fileToUpload).subscribe(
   
    data => {
    console.log("success")
    },
     error => {
      console.log(error);
    });
}
  ngOnInit() {
     
  }

  onLogoutClicked():void{
    localStorage.removeItem("currentUser");
  }

}
