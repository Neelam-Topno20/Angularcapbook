import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Profile } from '../profile';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})

export class EditProfileComponent implements OnInit {

  editForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private capbookService:CapBookService, private router:Router) { }

  ngOnInit() {
      this.editForm = this.formBuilder.group({
          emailId: ['', Validators.required],
          designation: ['', [Validators.required]],
          highestEducation: ['', [Validators.required],],
          userBio: ['', [Validators.required]],
          relationshipStatus:['',Validators.required],
          currentCity:['',Validators.required]
         
      });
  }

  errorMessage:string;
  message:string;
  // convenience getter for easy access to form fields
  get f() { return this.editForm.controls; }

  onSubmit() {
      this.submitted = true;
        console.log("On Submit")
      this.capbookService.editProfile(this.editForm).subscribe(
        message=>{
          this.message=message;
          console.log(this.message)
          alert('SUCCESS!!')
          this.router.navigateByUrl('/user-profile');
        },
        errorMessage=>{
          this.errorMessage=errorMessage;
          alert('Invalid Email Id!!')
        }
      );
          // stop here if form is invalid
      if (this.editForm.invalid) {
        return;
    } 
    

      }
      
     
  }
